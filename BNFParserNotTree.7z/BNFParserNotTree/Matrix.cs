﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;

namespace BNFParserNotTree
{
    class Matrix
    {
        private static LinkedList<LinkedList<string>> elements;
        private static int Rows;
        public Matrix(int number)
        {
            Rows = number;
            elements = new LinkedList<LinkedList<string>>();
            for (int i = 0; i < number; i++)
                elements.AddFirst(new LinkedList<string>());
        }
        public string this[int i,int j]
        {
            get { return elements.ElementAt(i).ElementAt(j); }
            set { elements.ElementAt(i).AddFirst(value); }
        }
        public int RowsCount()
        {
            return Rows;
        }
        public int ElementsInRow(int i)
        {
            return elements.ElementAt(i).Count();
        }

    }
}
