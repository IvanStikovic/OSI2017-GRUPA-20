﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;

namespace BNFParserNotTree
{
    class Parser
    {
        private static LinkedList<string> strings=new LinkedList<string>();
        private static LinkedList<string> TokensNames = new LinkedList<string>();
        private static LinkedList<string> TokensRegex=new LinkedList<string>();
        private static LinkedList<string> Matched = new LinkedList<string>();
        private static LinkedList<Node> Parents = new LinkedList<Node>();
        private static Node root=null;
        public static void ExecuteProgram(string inputFile,string outputFile)
        {
            LoadSpecialTokens();
            LoadConfig();
            MatchInput(inputFile,outputFile);
            WriteXML();
        }
        public static void LoadSpecialTokens()
        {
            var txtLines = File.ReadAllLines("specialTokens.txt");
            for(int ctr=0;ctr<txtLines.Count();ctr++)
            {
                string[] st = txtLines[ctr].Split("::=");
                TokensNames.AddLast(st[0]);
                TokensRegex.AddLast(st[1]);
            }
            LoadCities();
        }
        public static void LoadCities()
        {
            var txtLines = File.ReadAllLines("cities.txt").ToList();
            string citiesRegex = "";
            citiesRegex = txtLines[0];
            for(int ctr=1;ctr<txtLines.Count();ctr++) 
                citiesRegex +="|" + txtLines[ctr];
            TokensNames.AddLast("veliki_grad");
            TokensRegex.AddLast(citiesRegex);
        }
        public static void LoadConfig()
        {
            var txtLines = File.ReadAllLines("config.txt").ToList();

            Regex reg1 = new Regex(@"\<([^>]*)\>");
            Regex reg2 = new Regex("\"([^\"]*)\"");
            Regex reg3 = new Regex(@"\(([^)]*)\)");

            MatchCollection matches1;
            MatchCollection matches2;
            MatchCollection matches3;
            for(int i=0;i<txtLines.Count();i++)
            {

                matches1 = reg1.Matches(txtLines[i]);
                matches2 = reg2.Matches(txtLines[i]);
                matches3 = reg3.Matches(txtLines[i]);


                //kreiranje roditelja
               /* if (root == null)
                    root = new Node(false, matches1[0].Value, null);
                else
                {

                }

                for (int j = 1; j < matches1.Count(); j++)
                {
                    var parents = root.FindNode(root, matches1[0].Value).ToList();
                    for (int k = 0; k < parents.Count(); k++)
                        parents[k].AddSon(new Node(false, matches1[j].Value, parents[k].GetNodeValue()));
                }
                for (int j = 0; j < matches2.Count(); j++)
                {
                    var parents = root.FindNode(root, matches1[0].Value).ToList();
                    for (int k = 0; k < parents.Count(); k++)
                        parents[k].AddSon(new Node(true, matches2[j].Value, parents[k].GetNodeValue()));
                }
                for (int j = 0; j < matches3.Count(); j++)
                {
                    var parents = root.FindNode(root, matches1[0].Value).ToList();
                    for (int k = 0; k < parents.Count(); k++)
                        parents[k].AddSon(new Node(true, matches3[j].Value, parents[k].GetNodeValue()));
                }*/ 
                //do ovde


                string[] firstSplit = txtLines[i].Split("::=");
                firstSplit[1] = firstSplit[1].Replace("\"", "");
                string[] secondSplit = firstSplit[1].Split("|");
                


                for(int k=0;k<secondSplit.Count();k++)
                {
                    if(secondSplit[k].Contains(firstSplit[0]))
                    {
                        secondSplit[k] = secondSplit[k].Replace(firstSplit[0], "{2,}");
                    }
                }
                if (CheckExistence(matches1[0].Value))
                {
                    ReplaceElementsInList(matches1[0].Value,"("+firstSplit[1]+")");
                }
                else
                {
                    for (int ctr = 0; ctr < secondSplit.Count(); ctr++)
                        strings.AddLast(new string(secondSplit[ctr]));
                }
            }
            for(int i=0;i<strings.Count();i++)
            {
                strings.Find(strings.ElementAt(i)).Value = "^" + strings.ElementAt(i) +"$";
                strings.Find(strings.ElementAt(i)).Value = strings.ElementAt(i).Replace("regex", "");
                CheckForSpecialTokens(i);
            }
        }

        public static void CheckForSpecialTokens(int ctr)
        {
            for(int i=0;i<TokensNames.Count();i++)
            {
                if(strings.ElementAt(ctr).Contains(TokensNames.ElementAt(i)))
                {
                    strings.Find(strings.ElementAt(ctr)).Value = strings.ElementAt(ctr).Replace(TokensNames.ElementAt(i),TokensRegex.ElementAt(i));
                }
            }
        }
        public static bool CheckExistence(string value)
        {
            for (int j = 0; j < strings.Count(); j++)
                if (strings.ElementAt(j).Contains(value))
                     return true;
            return false;
        }

        public static void ReplaceElementsInList(string OldValue, string NewValue)
        {
            for (int j = 0; j < strings.Count(); j++)
                if (strings.ElementAt(j).Contains(OldValue))
                { 
                    string newString = strings.ElementAt(j);
                    newString = newString.Replace(OldValue,NewValue);
                    strings.Find(strings.ElementAt(j)).Value = newString;
                }
        }
        public static void MatchInput(string inputFile,string OutputFile)
        {
            var inputFileLines = File.ReadAllLines(inputFile).ToList();
            for (int i = 0; i < inputFileLines.Count(); i++)
            {
                bool isMatched = false;
                string line = inputFileLines[i];
                
                for (int ctr = 0; ctr < strings.Count(); ctr++)
                {
                    Regex regex = new Regex(strings.ElementAt(ctr));
                    MatchCollection matches = regex.Matches(line);
                    if(matches.Count()>0)
                    {
                        for (int k = 0; k < matches.Count(); k++)
                            Matched.AddLast(inputFileLines[i]);
                        isMatched = true;
                    }
                }
                if(isMatched==false)
                    Console.WriteLine("Nije moguce parsirati : {0}", inputFileLines[i]);
            }
        }
        public static void WriteXML()
        {
           LinkedList<LinkedList<string>> matrix = new LinkedList<LinkedList<string>>();
           for(int i=0;i<Matched.Count();i++)
            {
                
            }
            
        }
    }
}
