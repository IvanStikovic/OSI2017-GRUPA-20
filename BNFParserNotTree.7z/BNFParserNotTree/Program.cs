﻿using System;

namespace BNFParserNotTree
{
    class Program
    {
        static void Main(string[] args)
        {
            Parser.ExecuteProgram(args[0],args[1]);
            
        }
    }
}
