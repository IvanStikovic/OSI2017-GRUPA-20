﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;

namespace BNFParserNotTree
{
    class Node
    {
        //private int numberOfRepetions;
        private bool isTerminal;
        private String value;
        private String parent;
        private Regex regex;
        public LinkedList<Node> sons;
        public Node(bool isTerminal, String value, String parent)
        {
            sons = new LinkedList<Node>();
            //regex = new Regex(Regex);
            this.isTerminal = isTerminal;
            this.value = value;
            this.parent = parent;

        }

        public Node(Node node)
        {
            this.value = node.value;
            this.parent = node.parent;
            this.sons = new LinkedList<Node>();
            for (int i = 0; i < node.sons.Count(); i++)
                this.sons.AddLast(node.sons.ElementAt(i));
        }
        public void AddSon(Node node)
        {
            Node newSon = node;
            this.sons.AddLast(newSon);
        }
        public String GetNodeValue()
        {
            return value;
        }

        public void addRepetion()
        {
            //this.numberOfRepetions++;
        }

        public void SetParent(String parent)
        {
            this.parent = parent;
        }
        public  LinkedList<Node> FindNode(Node root, string value)
        {

            Queue<Node> q = new Queue<Node>();
            LinkedList<Node> list = new LinkedList<Node>();
            q.Enqueue(root);
            while (q.Count > 0)
            {
                Node current = q.Dequeue();

                if (current.GetNodeValue().Contains(value))
                    list.AddLast(current);

                if (current == null)
                    continue;

                foreach (Node child in current.sons)
                    q.Enqueue(child);

            }
            if (list.Count() == 0)
                return null;
            else return list;
        }
    }
}
